<?php
/* Database connection settings */
	$servername = "localhost";
    $username = "vnuagas_username";		//put your phpmyadmin username.(default is "root")
    $password = "Nam23456nam";			//if your phpmyadmin has a password put it here.(default is "root")
    $dbname = "vnuagas_database";
    
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
?>