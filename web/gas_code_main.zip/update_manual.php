<?php
require 'connectDB.php';
// Lấy dữ liệu JSON từ yêu cầu POST
$jsonData = file_get_contents('php://input');

// Kiểm tra xem dữ liệu JSON có hợp lệ không
if (empty($jsonData)) {
    header('HTTP/1.1 400 Baed Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
}

// Chuyển đổi dữ liệu JSON thành mảng trong PHP
$data = json_decode($jsonData, true);

// Kiểm tra xem chuyển đổi có thành công không
if ($data === null) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
} else {
    // Đọc dữ liệu từ mảng
    $number = $data['number'];
     if ($number  != 0 ) {
        $updateManualQuery = "UPDATE system_regime SET number_gas = '$number'";
        if(mysqli_query($conn, $updateManualQuery)){
        header('Content-Type: application/json');
        echo json_encode(array('success' => true, 'message' => 'Update number gas success'));
        }else{
             header('HTTP/1.1 502 Bad Request');
            echo json_encode(array('error' => 'Invalid Database'));
        exit;
        }
    } else {
        // Lỗi trong quá trình thực hiện truy vấn
        header('HTTP/1.1 400 Bad Request');
    }
}
