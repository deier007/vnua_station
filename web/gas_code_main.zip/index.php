<!DOCTYPE html>
<html lang="en">
<!-- Mirrored from colorlib.com/etc/lf/Login_v12/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 15 Oct 2023 10:55:45 GMT -->

<head>
    <title>Login</title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />

    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css" />

    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css" />

    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css" />

    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css" />

    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css" />

    <link rel="stylesheet" type="text/css" href="css/util.css" />
    <link rel="stylesheet" type="text/css" href="css/main.css" />

    <meta name="robots" content="noindex, follow" />

    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>

    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <script src="vendor/select2/select2.min.js"></script>

    <script src="js/main.js"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>

    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854" integrity="sha512-bjgnUKX4azu3dLTVtie9u6TKqgx29RBwfj3QXYt5EKfWM/9hPSAI/4qcV5NACjwAo8UtTeWefx6Zq5PHcMm7Tg==" data-cf-beacon='{"rayId":"8167880a9893079a","version":"2023.8.0","b":1,"token":"cd0b4b3a733644fc843ef0b185f98241","si":100}' crossorigin="anonymous"></script>

</head>

<body>
    <div class="limiter" id="allinfor">
        <div class="container-login100" style="background-image: url('images/img-01.jpg')">
            <div class="row">
                <!-- card 1 :: begin -->
                <div class="col" id="userCard">
                    <div class="card rounded" style="width: 18rem;">
                        <div class="d-flex justify-content-center align-items-center" style="height: 12rem;">
                            <img src="images/group.png" style="width: 40%;" class="card-img rounded" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h1 class="card-title">User</h1>
                            <a href="#" class="btn btn-primary">Go </a>
                        </div>
                    </div>

                </div>
                <!-- card 1 :: end -->

                <!-- card 2 :: begin -->
                <div class="col " id="adminCard">
                    <div class="card rounded" style="width: 18rem;">
                        <div class="d-flex justify-content-center align-items-center" style="height: 12rem;">
                            <img src="images/admin.png" style="width: 40%;" class="card-img rounded" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h1 class="card-title">Admin</h1>
                            <a href="login.php" class="btn btn-primary">Go </a>
                        </div>
                    </div>

                </div>
                <!-- card 2 :: end -->



            </div>

        </div>
    </div>

</body>


</html>

<script>
    // JavaScript code
    // Lấy danh sách các phần tử cần làm mờ
    var otherElements = document.querySelectorAll(".card:not(:first-child)");

    document.getElementById("userCard").addEventListener("click", function() {
        // Thêm hiệu ứng blur cho admin card
        document.getElementById("allinfor").style.filter = "blur(20px)";
        // Tạo một phần tử hình ảnh
        var qrImage = document.createElement("img");
        qrImage.src = "images/qrloginuser.png";
        qrImage.alt = "QR Code Login";
        qrImage.style.width = "400px"; // Đặt kích thước hình ảnh nếu cần thiết
        qrImage.style.borderRadius = "22px"; // Thêm border với độ rộng 2px và màu đen (#000)
        // Tạo nút "Back" để thoát khỏi chế độ blur
        var backButton = document.createElement("button");
        backButton.textContent = "Back";
        backButton.className = "btn btn-danger";


        backButton.addEventListener("click", function() {
            // Loại bỏ hiệu ứng blur khi nút "Back" được nhấp
            document.getElementById("allinfor").style.filter = "none";
            // Loại bỏ hình ảnh và nút "Back" khỏi trang
            document.body.removeChild(qrImage);
            document.body.removeChild(backButton);
        });

        // Thêm hình ảnh vào trang
        document.body.appendChild(qrImage);
        document.body.appendChild(backButton);

        qrImage.style.position = "fixed";
        qrImage.style.top = "50%";
        qrImage.style.left = "50%";
        qrImage.style.transform = "translate(-50%, -50%)";
    });
</script>


<script>
    // Hàm để gửi yêu cầu AJAX
    function sendAjaxRequest() {
        $.ajax({
            url: 'check_now.php',
            type: 'GET',
            dataType: 'json',
            success: function(data) {
                // Kiểm tra giá trị trường 'user' từ phản hồi JSON
                if (data.user !== "0") {
                    // Chuyển hướng tới trang 'user.php'
                    window.location.href = 'user.php';
                }
            },
            error: function(error) {
                console.error('Đã xảy ra lỗi:', error);
            }
        });
    }

    // Gửi yêu cầu AJAX mỗi giây
    setInterval(sendAjaxRequest, 1000); // 1000 milliseconds = 1 giây
</script>
<style>
    /* CSS code */
    #allinfor {
        transition: filter 0.3s ease;
        /* Thêm hiệu ứng transition cho hiệu ứng blur */
    }

    .btn-danger {
        position: absolute;
        top: 96%;
        right: 45%;
        transform: translate(-50%, -50%);
    }
</style>