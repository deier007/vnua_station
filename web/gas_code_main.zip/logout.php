<?php
	session_start();
	session_unset();
	session_destroy();
	require 'connectDB.php';

	$query = "UPDATE user_now SET user = 0";
	$result = mysqli_query($conn, $query);
	
	header("location: index.php");
?>