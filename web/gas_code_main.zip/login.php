<?php
session_start();
if (isset($_SESSION['Admin-name'])) {
  header("location: admin.php");
}
?>
<?php
if (isset($_GET['error'])) {
  if ($_GET['error'] == "invalidEmail") {
    echo '<div class="alert alert-danger">
                        This E-mail is invalid!!
                      </div>';
  } elseif ($_GET['error'] == "sqlerror") {
    echo '<div class="alert alert-danger">
                        There a database error!!
                      </div>';
  } elseif ($_GET['error'] == "wrongpassword") {
    echo '<div class="alert alert-danger">
                        Wrong password!!
                      </div>';
  } elseif ($_GET['error'] == "nouser") {
    echo '<div class="alert alert-danger">
                        This E-mail does not exist!!
                      </div>';
  }
}
if (isset($_GET['reset'])) {
  if ($_GET['reset'] == "success") {
    echo '<div class="alert alert-success">
                        Check your E-mail!
                      </div>';
  }
}
if (isset($_GET['account'])) {
  if ($_GET['account'] == "activated") {
    echo '<div class="alert alert-success">
                        Please Login
                      </div>';
  }
}
if (isset($_GET['active'])) {
  if ($_GET['active'] == "success") {
    echo '<div class="alert alert-success">
                        The activation like has been sent!
                      </div>';
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <title>Login </title>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <link rel="icon" type="image/png" href="images/icons/favicon.ico" />

  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css" />

  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" />

  <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css" />

  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css" />

  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css" />

  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css" />

  <link rel="stylesheet" type="text/css" href="css/util.css" />
  <link rel="stylesheet" type="text/css" href="css/main.css" />

  <meta name="robots" content="noindex, follow" />
  <script nonce="a07f8658-ebb5-4366-b5ba-df9e916feeb0">
    (function(w, d) {
      !(function(a, b, c, d) {
        a[c] = a[c] || {};
        a[c].executed = [];
        a.zaraz = {
          deferred: [],
          listeners: []
        };
        a.zaraz.q = [];
        a.zaraz._f = function(e) {
          return async function() {
            var f = Array.prototype.slice.call(arguments);
            a.zaraz.q.push({
              m: e,
              a: f
            });
          };
        };
        for (const g of ["track", "set", "debug"]) a.zaraz[g] = a.zaraz._f(g);
        a.zaraz.init = () => {
          var h = b.getElementsByTagName(d)[0],
            i = b.createElement(d),
            j = b.getElementsByTagName("title")[0];
          j && (a[c].t = b.getElementsByTagName("title")[0].text);
          a[c].x = Math.random();
          a[c].w = a.screen.width;
          a[c].h = a.screen.height;
          a[c].j = a.innerHeight;
          a[c].e = a.innerWidth;
          a[c].l = a.location.href;
          a[c].r = b.referrer;
          a[c].k = a.screen.colorDepth;
          a[c].n = b.characterSet;
          a[c].o = new Date().getTimezoneOffset();
          if (a.dataLayer)
            for (const n of Object.entries(
                Object.entries(dataLayer).reduce(
                  (o, p) => ({
                    ...o[1],
                    ...p[1]
                  }), {}
                )
              ))
              zaraz.set(n[0], n[1], {
                scope: "page"
              });
          a[c].q = [];
          for (; a.zaraz.q.length;) {
            const q = a.zaraz.q.shift();
            a[c].q.push(q);
          }
          i.defer = !0;
          for (const r of [localStorage, sessionStorage])
            Object.keys(r || {})
            .filter((t) => t.startsWith("_zaraz_"))
            .forEach((s) => {
              try {
                a[c]["z_" + s.slice(7)] = JSON.parse(r.getItem(s));
              } catch {
                a[c]["z_" + s.slice(7)] = r.getItem(s);
              }
            });
          i.referrerPolicy = "origin";
          i.src =
            "../../../cdn-cgi/zaraz/sd0d9.js?z=" +
            btoa(encodeURIComponent(JSON.stringify(a[c])));
          h.parentNode.insertBefore(i, h);
        };
        ["complete", "interactive"].includes(b.readyState) ?
          zaraz.init() :
          a.addEventListener("DOMContentLoaded", zaraz.init);
      })(w, d, "zarazData", "script");
    })(window, document);
  </script>
</head>

<body>
  <div class="limiter">
    <div class="container-login100" style="background-image: url('images/img-01.jpg')">
      <div class="wrap-login100 p-t-190 p-b-30">
        <form class="login100-form validate-form" action="ac_login.php" method="post" enctype="multipart/form-data ">
          <div class="login100-form-avatar">
            <img src="images/avatar-01.jpg" alt="AVATAR" />
          </div>
          <span class="login100-form-title p-t-20 p-b-45"> Gas Station </span>
          <div class="wrap-input100 validate-input m-b-10" data-validate="Username is required">
            <input class="input100" type="text" name="email" placeholder="Username" />
            <span class="focus-input100"></span>
            <span class="symbol-input100">
              <i class="fa fa-user"></i>
            </span>
          </div>
          <div class="wrap-input100 validate-input m-b-10" data-validate="Password is required">
            <input class="input100" type="password" name="pwd" placeholder="Password" />
            <span class="focus-input100"></span>
            <span class="symbol-input100">
              <i class="fa fa-lock"></i>
            </span>
          </div>
          <div class="container-login100-form-btn p-t-10">
            <button type="submit " name="login" class="login100-form-btn">Login</button>
          </div>
          <div class="container-login100-form-btn p-t-10">
            <button type="submit " name="back" class="login100-form-btn">Back</button>
          </div>
          <div class="text-center w-full p-t-25 p-b-230">
            <a href="#" class="txt1"> Forgot Username / Password? </a>
          </div>
          <div class="text-center w-full">
            <a class="txt1" href="#">
              Create new account
              <i class="fa fa-long-arrow-right"></i>
            </a>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script src="vendor/jquery/jquery-3.2.1.min.js"></script>

  <script src="vendor/bootstrap/js/popper.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="vendor/select2/select2.min.js"></script>

  <script src="js/main.js"></script>

  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag("js", new Date());

    gtag("config", "UA-23581568-13");
  </script>
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854" integrity="sha512-bjgnUKX4azu3dLTVtie9u6TKqgx29RBwfj3QXYt5EKfWM/9hPSAI/4qcV5NACjwAo8UtTeWefx6Zq5PHcMm7Tg==" data-cf-beacon='{"rayId":"8167880a9893079a","version":"2023.8.0","b":1,"token":"cd0b4b3a733644fc843ef0b185f98241","si":100}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from colorlib.com/etc/lf/Login_v12/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 15 Oct 2023 10:55:49 GMT -->

</html>