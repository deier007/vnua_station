const wrapper = document.querySelector(".wrapper"),
  qrInput = wrapper.querySelector(".form input"),
  generateBtn = wrapper.querySelector(".form button"),
  qrImg = wrapper.querySelector(".qr-code img");
let preValue;
generateBtn.addEventListener("click", () => {
  $.ajax({
    url: "generateQRCode.php",
    type: "GET",
    dataType: "json",
    success: function (data) {
      let user = data.admin_name; // Assuming your JSON response contains the key "admin_name"
      let qrValue = `{"user": "${user}", "money": ${qrInput.value.trim()}}`;

      if (!qrValue || preValue === qrValue) return;
      preValue = qrValue;

      generateBtn.innerText = "Generating QR Code...";
      qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(
        qrValue
      )}`;

      qrImg.onload = function () {
        wrapper.classList.add("active");
        generateBtn.innerText = "Generate QR Code";
      };
    },
    error: function (error) {
      console.error("Đã xảy ra lỗi:", error);
    },
  });
});
qrInput.addEventListener("keyup", () => {
  if (!qrInput.value.trim()) {
    wrapper.classList.remove("active");
    preValue = "";
  }
});
