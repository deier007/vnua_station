<?php
require 'connectDB.php';

// Lấy dữ liệu JSON từ yêu cầu POST
$jsonData = file_get_contents('php://input');

// Kiểm tra xem dữ liệu JSON có hợp lệ không
if (empty($jsonData)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
}

// Chuyển đổi dữ liệu JSON thành mảng trong PHP
$data = json_decode($jsonData, true);

// Kiểm tra xem chuyển đổi có thành công không
if ($data === null) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
} else {
    // Đọc dữ liệu từ mảng
    $auto = $data['auto'];
    $number = $data['number'];
    if ($auto == 1 ) {
        $updateAutoQuery = "UPDATE system_regime SET auto = 1, manual = 0, number_gas = 0 ";
        if(mysqli_query($conn, $updateAutoQuery)){
            header('HTTP/1.1 200 OK');
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Update regime success'));
        } else {
            header('HTTP/1.1 500 Internal Server Error');
            header('Content-Type: application/json');
            echo json_encode(array('success' => false, 'message' => 'Failed to update regime'));
        }
    } else if ( $auto == 0 && $number !=0 ) {
        $updateManualQuery = "UPDATE system_regime SET manual = 1, auto = 0, number_gas = '$number' ";
        if(mysqli_query($conn, $updateManualQuery)){
            header('HTTP/1.1 200 OK');
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Update regime success'));
        } else {
            header('HTTP/1.1 500 Internal Server Error');
            header('Content-Type: application/json');
            echo json_encode(array('success' => false, 'message' => 'Failed to update regime'));
        }
    } else {
        // Lỗi trong quá trình thực hiện truy vấn
        header('HTTP/1.1 400 Bad Request');
        header('Content-Type: application/json');
        echo json_encode(array('success' => false, 'message' => 'Invalid request parameters'));
    }

    // Đóng kết nối với cơ sở dữ liệu
    mysqli_close($conn);
}
?>