<?php
require 'connectDB.php';

// Thực hiện truy vấn SQL để lấy thông tin từ bảng admin
$query = "SELECT admin_name, money FROM admin";
$result = mysqli_query($conn, $query);

if ($result) {
    // Tạo một mảng để lưu trữ thông tin từ kết quả truy vấn
    $data = array();

    // Lặp qua các dòng kết quả và thêm vào mảng
    while ($row = mysqli_fetch_assoc($result)) {
        // Chuyển trường "money" thành số tự nhiên
        $row['money'] = intval($row['money']);
        $data = $row;
    }

    // Trả về dữ liệu dưới dạng JSON
    header('Content-Type: application/json');
    echo json_encode($data);
} else {
    // Lỗi trong quá trình thực hiện truy vấn
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: application/json');
    echo json_encode(array('error' => 'Failed to fetch data from database'));
}

// Đóng kết nối với cơ sở dữ liệu
mysqli_close($conn);
?>
