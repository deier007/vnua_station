<?php
require 'connectDB.php';

// Lấy dữ liệu JSON từ yêu cầu POST
$jsonData = file_get_contents('php://input');

// Kiểm tra xem dữ liệu JSON có hợp lệ không
if (empty($jsonData)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
}

// Chuyển đổi dữ liệu JSON thành mảng trong PHP
$data = json_decode($jsonData, true);

// Kiểm tra xem chuyển đổi có thành công không
if ($data === null) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
} else {
    // Đọc dữ liệu từ mảng
    $user = $data['user'];
    $money = $data['money'];
  
    // Cập nhật trường "money" trong bảng admin dựa trên giá trị của "user"
    $updateQuery = "UPDATE admin SET money = '$money' WHERE admin_name = '$user'";
    
    // Thực hiện truy vấn cập nhật
    if (mysqli_query($conn, $updateQuery)) {
        // Trả về thông báo thành công
        echo json_encode(array('message' => 'Update successful'));
    } else {
        // Trả về thông báo lỗi nếu truy vấn cập nhật không thành công
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode(array('error' => 'Failed to update data'));
    }
    
    // Đóng kết nối với cơ sở dữ liệu
    mysqli_close($conn);
}
?>
