<?php
// Assuming you have a database connection established
require 'connectDB.php';
// Fetch data from the database
$query = "SELECT timeaxis, stock,sold FROM fuel";
$result = mysqli_query($conn, $query);

// Chuyển đổi kết quả thành mảng JSON
$data = array();
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

echo json_encode($data);

mysqli_close($conn);
?>