<?php include 'header.php'; ?>

<!DOCTYPE html>
<html>

<head>
    <title>Users</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.3.2/css/buttons.dataTables.min.css">
    <link rel="icon" type="image/png" href="images/favicon.png">
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.3.2/js/buttons.html5.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/mainadmin.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body>
    <!-- CHART :: BEGIN -->
    <div class="col"></div>
    </div>

    </div>
    <!-- card 2 end -->
    <div class="row container-fluid">
        <div id="mySidenav" class="sidenav">
            <a href="admin.php" id="about">Back</a>

        </div>
        <div class="col"><canvas id="myChart"></canvas></div>
    </div>
    <div class="row">

    </div>
    </div>
</body>

</html>

<script>
    const labels = [];
    const data = {
        labels: labels,
        datasets: [{
                label: 'Xăng trong bồn ',
                backgroundColor: 'rgb(255, 99, 132)',
                borderColor: 'rgb(255, 99, 132)',
                data: [],
                pointStyle: 'circle',
                pointRadius: 5,
                pointHoverRadius: 8
            },
            {
                label: 'Xăng đã bán',
                backgroundColor: 'rgb(54, 162, 235)',
                borderColor: 'rgb(54, 162, 235)',
                data: [],
                stack: 'combined',
                type: 'bar',
                pointStyle: 'circle',
                pointRadius: 5,
                pointHoverRadius: 8

            }
        ]
    };

    const config = {
        type: 'bar',
        data: data,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Thông số'
                }
            }
        },
    };
    const myChart = new Chart(document.getElementById('myChart'), config);

    // Hàm để cập nhật dữ liệu từ bảng temp bằng AJAX
    function fetchDataAndUpdateChart() {
        // Sử dụng AJAX để lấy dữ liệu từ máy chủ
        $.ajax({
            url: 'fetch_temp.php',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                // Xử lý dữ liệu nhận được từ máy chủ
                const stock = [];
                const sold = [];

                const timeAxisData = [];

                // Lặp qua dữ liệu nhận được và thêm vào các mảng tương ứng
                response.forEach(function(dataPoint) {
                    stock.push(parseFloat(dataPoint.stock)); // Chuyển đổi giá trị thành số và thêm vào mảng nhiệt độ
                    timeAxisData.push(dataPoint.timeaxis); // Thêm thời gian vào mảng trục x
                    sold.push(dataPoint.sold);

                });

                // Cập nhật dữ liệu trên biểu đồ
                myChart.data.labels = timeAxisData;
                myChart.data.datasets[0].data = stock;
                myChart.data.datasets[1].data = sold;


                // Cập nhật biểu đồ
                myChart.update();
            },
            error: function(error) {
                console.error('Error fetching data:', error);
            }
        });
    }
    $(document).ready(function() {
        fetchDataAndUpdateChart(); // Gọi hàm khi trang được tải lần đầu tiên
        setInterval(fetchDataAndUpdateChart, 1000); // Lặp gọi hàm mỗi 10 giây
    });
</script>