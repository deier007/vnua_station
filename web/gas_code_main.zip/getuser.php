<?php
require 'connectDB.php';

// Lấy dữ liệu JSON từ yêu cầu POST
$jsonData = file_get_contents('php://input');

// Kiểm tra xem dữ liệu JSON có hợp lệ không
if (empty($jsonData)) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
}

// Chuyển đổi dữ liệu JSON thành mảng trong PHP
$data = json_decode($jsonData, true);

// Kiểm tra xem chuyển đổi có thành công không
if ($data === null) {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(array('error' => 'Invalid JSON data'));
    exit;
} else {
    // Đọc dữ liệu từ mảng
    $user = $data['user'];
    $pwd = $data['pwd'];
    
    // Thực hiện truy vấn SQL để kiểm tra thông tin đăng nhập
    $query = "SELECT * FROM admin WHERE admin_email = '$user' AND admin_pwd = '$pwd'";
    $result = mysqli_query($conn, $query);

    // Kiểm tra xem có kết quả từ truy vấn không
    if ($result) {
        // Kiểm tra số dòng kết quả trả về từ truy vấn
        if (mysqli_num_rows($result) > 0) {
            // Nếu có dòng kết quả, tức là tìm thấy thông tin đăng nhập
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Login successful'));
        } else {
            // Không tìm thấy thông tin đăng nhập
             header('HTTP/1.1 404 Bad Request');
            header('Content-Type: application/json');
            echo json_encode(array('success' => false, 'message' => 'Login failed. Incorrect email or password.'));
        }
    } else {
        // Lỗi trong quá trình thực hiện truy vấn
        header('Content-Type: application/json');
        echo json_encode(array('success' => false, 'message' => 'Error occurred while processing your request.'));
    }

    // Đóng kết nối với cơ sở dữ liệu
    mysqli_close($conn);
}
?>
