<?php include 'header.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Login </title>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />

    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css" />

    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css" />

    <link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css" />

    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css" />

    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css" />

    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css" />

    <link rel="stylesheet" type="text/css" href="css/util.css" />
    <link rel="stylesheet" type="text/css" href="css/main.css" />
    <link rel="stylesheet" type="text/css" href="css/mainadmin.css" />
    <meta name="robots" content="noindex, follow" />

    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>

    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <script src="vendor/select2/select2.min.js"></script>

    <script src="js/main.js"></script>

    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>

    <script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8b253dfea2ab4077af8c6f58422dfbfd1689876627854" integrity="sha512-bjgnUKX4azu3dLTVtie9u6TKqgx29RBwfj3QXYt5EKfWM/9hPSAI/4qcV5NACjwAo8UtTeWefx6Zq5PHcMm7Tg==" data-cf-beacon='{"rayId":"8167880a9893079a","version":"2023.8.0","b":1,"token":"cd0b4b3a733644fc843ef0b185f98241","si":100}' crossorigin="anonymous"></script>

</head>

<body>
    <div class="limiter">
        <div class="container-login100" style="background-image: url('images/img-01.jpg')">

            <div class="row">


                <!-- card 2 :: begin -->
                <div class="col">
                    <div class="card rounded" style="width: 18rem;">
                        <div class="d-flex justify-content-center align-items-center" style="height: 12rem;">
                            <img src="images/admin.png" style="width: 40%;" class="card-img rounded" alt="...">
                        </div>
                        <div class="card-body text-center">
                            <h1 class="card-title">Xin chào</h1>
                            <h2 class="card-title" id="user_name"></h2>
                            <a href="login.php" class="btn btn-primary">Go </a>
                        </div>
                    </div>

                </div>
                <!-- card 2 :: end -->



            </div>
            <div id="mySidenav" class="sidenav">
                <a href="chart.php" id="about">Biểu Đồ</a>
                <a href="logout.php" id="contact">Logout</a>
            </div>



        </div>
    </div>

</body>


</html>